<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel frontend\models\ForumAnswersSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Forum Answers';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="forum-answers-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Forum Answers', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'ques_id',
            'answer:ntext',
            'user_id',
            'admin_approve',
            // 'ans_on',
            // 'correct_answer',
            // 'type',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
