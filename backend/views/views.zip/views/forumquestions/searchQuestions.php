<?php use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use frontend\models\ForumQuestions;
use frontend\models\User;
use frontend\models\UserPackage;
use frontend\models\ForumAnswers;
use backend\models\HelpInfo;
use frontend\models\ForumAnswerFiles;
use frontend\models\ForumQuestionFiles;

$baseUrl = Yii::$app->getUrlManager()->getBaseUrl();
?>

<div id="support_forum" class="discussionForum">
    <div class="tabs-icons">
   		<h1 class="text pull-left">Ask Us How</h1>
		<div class="clearfix"></div>
	</div>
    <div class="ask-question">
    <?php
		//code to get current week message limit for trial and single user 
		$userPckgId = UserPackage::getUserPackageDetails(Yii::$app->user->getId());
		$pckgLimit = UserPackage::getPackageLimitByType('message'); 
		if ($pckgLimit != -1) {
			if (date('D') != 'Mon') {
				$staticstart = date('Y-m-d', strtotime('last Monday'));
			} else {
				$staticstart = date('Y-m-d');
			}
			if (date('D') != 'Sun') {
				$staticfinish = date('Y-m-d', strtotime('next Sunday'));
			} else {
				$staticfinish = date('Y-m-d');
			}                
			$countWeekMessage = ForumQuestions::getMessagesBetweenDate($staticstart, $staticfinish);
			$availableLimit = $pckgLimit - $countWeekMessage;
			if($availableLimit > 0) {
			   ?>
    <?= Html::button('ask a question', ['class'=> 'btn btn-inverse q-ask','onclick' => 'showForm()', 'id' => "btnAskQuestion"]) ;?>
<?php 
     } else {
?>            
        <div class="pull-left limit-exceed">
            <span class="rpt-limit badge-warning">Your Message limit exceeded for current week.</span>                
        </div>
            
		<?php
            }
        } else { ?>
            
                <?= Html::submitButton('ask a question', ['class'=> 'btn btn-inverse q-ask','onclick' => 'showForm()', 'id' => "btnAskQuestion"]) ;?>

     	<?php   }
        
        ?>   
        <div class="searchbox pull-right">
                    <?php $form = ActiveForm::begin([
                    'layout'=>'horizontal',
                    'id'=>'forum-questions-form',
                    'action'=>'admin',
                    'method'=>'post',
                    'options' => [
                    'class' => 'pull-right',
                    'enctype'=>'multipart/form-data',  
                    'name'=>'forumquestions',
                     ],
                ]); ?>
			<?=  $form->field($model, 'question')->textInput()->input('', ['placeholder' => "Search..."])->label(false); ?>
            <?= Html::submitButton('', ['class'=> 'btn btn-inverse q-search']) ;?>
	    	<?php ActiveForm::end(); ?>
		</div> 
        <div class="clearfix"></div>
  </div>
    <div class="fr supp">
    </div>
    <div class="clr"></div>
    <?php
   /* $this->widget('bootstrap.widgets.TbAlert', array(
        'block' => true, // display a larger alert block?
        'fade' => true, // use transitions?
        'closeText' => '×', // close link text - if set to false, no close link is displayed
        'alerts' => array(// configurations per alert type
            'success' => array('block' => true, 'fade' => true, 'closeText' => '×'), // success, info, warning, error or danger
            'warning' => array('block' => true, 'fade' => true, 'closeText' => '×'), // success, info, warning, error or danger
            'info' => array('block' => true, 'fade' => true, 'closeText' => '×'),
        ),
    ));  */
    ?>
    <div class="clr"></div>
    <?php if(($pckgLimit != -1 && $availableLimit > 0) || $pckgLimit == -1) { ?>
    <div id="AskQuestionForm" class="no-display">
        <?php
        //  echo $this->render('_form', array('model' => $model), false);
        if(isset($forumQuestionFiles)) {
            echo $this->render('_form', array('model' => $model, 'forumQuestionFiles' => $forumQuestionFiles));
        } else {
            echo $this->render('_form', array('model' => $model));
        }    
        ?>
    </div>
    <?php } ?>
    <?php
    if (!empty($forumQue)) {
        ?>	
        <table border="0" class="ClsQueAnswers" cellpadding="10">
            <TR class="QueHeader">
                <!--                <TD class="QnoHeader first">Sr.no</TD>-->
                <TD class="QHeader first" >Question</TD>
                <TD class="headerStatus">Status</TD>
                <TD class="onHeader last">Date</TD>
            </TR>
            <?php
            $i = 1;
            foreach ($forumQue as $fq) {
                $stat = $fq['admin_approve'];
                $QueReplies = ForumQuestions::GetQuestionReplies($fq['id']);
                ?>
                <TR class="<?php if ($i % 2 == 0) {
            echo "even";
        } else {
            echo "odd";
        } ?>" >
        <!--                    <TD class="v_align_top centerAll border-white yellow-left" style="vertical-align:top"><?php //echo $i;  ?></TD>-->
                    <TD class="v_align_top border-white yellow-left">
                        <p class="QuestionText">
                            <span onclick="displayinfo(<?php echo $fq['id'] ?>);"><?php echo $fq['question']; ?></span>  
                            <span onclick="displayinfo(<?php echo $fq['id'] ?>);" class="pull-right"></span>
                        </p>
                        <?php
                            $fileLoc = ForumQuestionFiles::getFileNameFromQuestionId($fq['id']);
                            $showLightBox = 0;
                            $showLightPDF = 0;
                            if(!empty($fileLoc)) {
                                foreach($fileLoc as $loc) {                                    
                                    $filePath = $loc['file_path']; 
                                    $path_parts = pathinfo($filePath);
                                    $fileExt =  $path_parts['extension'];
                                    if($fileExt == 'pdf') {
                                        $showLightPDF = 1;
                                        // ForumQuestionFiles::generateQuesFiles($fq['id']);                                   
                                    } else {
                                        $showLightBox = 1;  
                                    }
                                }
                                if($showLightPDF == 1) {
                                    ForumQuestionFiles::generateQuesFiles($fq['id']);  
                                }
                                if($showLightBox == 1) {
                                   $items = ForumQuestionFiles::generateQuesImages($fq['id']);  
                                   foreach($items as $key => $val) {
                                       $fileId = $val['options']['id'];
                                       ?>
                                        <i class="glyphicon glyphicon-remove removeimage" id="img-<?php echo $fileId ;?>" type=1 onclick="return confirmDelete(<?php echo $fileId; ?>,1);"></i>      
                                 <?php  }
                                   
                                    $rand = mt_rand(10,1000);
                                    echo dosamigos\gallery\Gallery::widget([
                                       'items' => $items,
                                       'options' => [
                                           'id' => 'gallery-widget-' . $fq['id'].$rand,
                                        ],
                                        'templateOptions' => [
                                            'id' => 'blueimp-gallery-' . $fq['id'].$rand
                                        ],
                                        'clientOptions' => [
                                            'container' => '#blueimp-gallery-' . $fq['id'].$rand
                                        ]
                                   ]);                                
                                }
                            } 
                        ?>
                            <?php
                            if (!empty($QueReplies)) {
                                ?>
                            <p class="pull-left answer-restrict">
                            <?php
                                $ans = substr($QueReplies[0]['answer'], 0, 25);
                                $ans.='...';
                            ?>
                                <span class='expand-ques' onclick="displayinfo(<?php echo $fq['id'] ?>);"><?php echo $ans; ?></span>
                            </p>
                            <div class="clr"></div>
                            <div class="divAns no-display ans_<?php echo $fq['id']; ?>">
                                <table border="0" class="tblAnswers first last" cellpadding="5">
                                        <?php
                                        $j = 1;
                                        foreach ($QueReplies as $rply) {
                                            $replyRole = \frontend\models\UserRole::findOne($rply['user_id']);
                                            if($replyRole['role_id'] == 1) {
                                                    $classOfUser = 'admin-user';
                                                    $rply['answer'];
                                                    $labelfor = '<span class="s">Admin: </span>';
                                            } else {
                                                    $classOfUser = 'user-user';
                                                    $labelfor = '<span class="reply-lb">User: </span>';
                                            }
                                            ?>
                                        <TR class="<?php echo $classOfUser; ?>">
                                                <?php
                                                if ($j == 1) {
                                                    ?>
                                                <TD class="ansText">
                                                  
                                                    <?php
                                                    if ($rply['correct_answer'] == '1') {
                                                        ?>
                                                        <img src="<?php echo $baseUrl; ?>/frontend/web/blue/images/tick.png" title="Marked as right answer" alt="right answer"/>
                                                    <?php
                                                }
                                                    echo $labelfor;
                                                    echo '<span class="ans">'.$rply['answer'].'</span>';
                                                    echo '<div class="clearfix"></div>';
                                                    /* Added by Swati - for  showing attachemnt & lightbox gallery for images */ 
                                                    $showLightBox = 0;
                                                    $showLightPDF = 0;
                                                    // ForumAnswerFiles::generateAnswerPath($rply['id']);  // Added by Swati                                                   
                                                    $fileLoc = ForumAnswerFiles::getFileNameFromAnswersId($rply['id']);                                                    
                                                    if(!empty($fileLoc)) {  
                                                        foreach($fileLoc as $loc) {
                                                            $filePath = $loc['file_path']; 
                                                            $path_parts = pathinfo($filePath);
                                                            $fileExt =  $path_parts['extension'];
                                                            if($fileExt == 'pdf') {
                                                                // ForumAnswerFiles::generateAnsFiles($rply['id']); 
                                                                $showLightPDF = 1;
                                                            } else if($fileExt == 'jpg' || $fileExt == 'png') {
                                                                $showLightBox = 1;                                                        
                                                            }                                                       
                                                        }
                                                        if($showLightPDF == 1) {
                                                            ForumAnswerFiles::generateAnsFiles($rply['id']); 
                                                        }
                                                        if($showLightBox == 1) {
                                                            $items = ForumAnswerFiles::generateAnsImages($rply['id']);
                                                            foreach($items as $key => $val) {
                                                                $fileId = $val['options']['id'];
                                                            ?>
                                                                <i class="glyphicon glyphicon-remove removeimage" id="img-<?php echo $fileId ;?>" type=2 onclick="return confirmDelete(<?php echo $fileId; ?>,2);"></i>      
                                                            <?php   }
                                                            //echo dosamigos\gallery\Gallery::widget(['items' => $items]);
                                                            echo dosamigos\gallery\Gallery::widget([
                                                            'items' => $items,
                                                                'options' => [
                                                                    'id' => 'gallery-widget-' . $rply['id'],
                                                                ],
                                                                'templateOptions' => [
                                                                    'id' => 'blueimp-gallery-' . $rply['id']
                                                                ],
                                                                'clientOptions' => [
                                                                    'container' => '#blueimp-gallery-' . $rply['id']
                                                                ]
                                                            ]);
                                                        }
                                                    } 
                                                    /* End Swati */
                                                ?> 
                                                </TD> <TD class="ansPostedOn number"><?php  echo Yii::$app->formatter->asDate($rply['ans_on']); ?></TD>     
                                                    <?php
                                                } else {
                                                    ?>
                                                <TD class="ansText">
                                                    <?php
                                                    if ($rply['correct_answer'] == '1') {
                                                        ?>
                                                        <img src="<?php echo $baseUrl; ?>/frontend/web/blue/images/tick.png" title="Marked as right answer" alt="right answer"/>
                                                    <?php
                                                }
                                                   
                                                    echo '<span class="ans">'.$rply['answer'].'</span>';
                                                    echo '<div class="clearfix"></div>';
                                                    /* Added by Swati - for  showing attachemnt & lightbox gallery for images */ 
                                                    $showLightBox = 0;
                                                    $showLightPDF = 0;
                                                    // ForumAnswerFiles::generateAnswerPath($rply['id']);  // Added by Swati                                                   
                                                    $fileLoc = ForumAnswerFiles::getFileNameFromAnswersId($rply['id']);                                                   
                                                    if(!empty($fileLoc)) {  
                                                        foreach($fileLoc as $loc) {
                                                            $filePath = $loc['file_path']; 
                                                            $path_parts = pathinfo($filePath);
                                                            $fileExt =  $path_parts['extension'];
                                                            if($fileExt == 'pdf') {
                                                                //  ForumAnswerFiles::generateAnsFiles($rply['id']); 
                                                                $showLightPDF = 1;
                                                            } else if($fileExt == 'jpg' || $fileExt == 'png') {
                                                                $showLightBox = 1;                                                        
                                                            }                                                       
                                                        }
                                                        if($showLightPDF == 1) {
                                                            ForumAnswerFiles::generateAnsFiles($rply['id']); 
                                                        }
                                                        if($showLightBox == 1) {
                                                            $items = ForumAnswerFiles::generateAnsImages($rply['id']);
                                                            foreach($items as $key => $val) {
                                                                $fileId = $val['options']['id'];
                                                            ?>
                                                                <i class="glyphicon glyphicon-remove removeimage" id="img-<?php echo $fileId ;?>" type=2 onclick="return confirmDelete(<?php echo $fileId; ?>,2);"></i>      
                                                            <?php   }
                                                            //echo dosamigos\gallery\Gallery::widget(['items' => $items]);
                                                            echo dosamigos\gallery\Gallery::widget([
                                                            'items' => $items,
                                                                'options' => [
                                                                    'id' => 'gallery-widget-' . $rply['id'],
                                                                ],
                                                                'templateOptions' => [
                                                                    'id' => 'blueimp-gallery-' . $rply['id']
                                                                ],
                                                                'clientOptions' => [
                                                                    'container' => '#blueimp-gallery-' . $rply['id']
                                                                ]
                                                            ]);
                                                        }
                                                    } 
                                                    /* End Swati */
                                                ?>
                                                </TD>   <TD class="ansPostedOn number"><?php  echo Yii::$app->formatter->asDate($rply['ans_on']); ?></TD>                                              
                                                <?php } ?>
                                                                              
                                        </TR>
                                        <tr>                                    
                                            <td class="post-by" colspan="2">
                                                <?php
                                                $uid = $rply['user_id'];
                                                $fullname = User::getFullName($uid);
                                                if ($j > 1)
                                                    //echo 'Posted By-' . $fullname[0]['first_name'] . ' ' . $fullname[0]['last_name'];
                                                ?>
                                            </td>
                                        </tr>
                <?php
                $j++;
            }
            ?>
                                    <tr> 
                                        <TD class="anReplyLink">
                                            <div id="ReplyBox<?php echo $fq['id']; ?>" class="ReplyTxtBox no-display" >
            <?php
            $model = new ForumAnswers;
            $forumAnswerFiles = new ForumAnswerFiles;  // Added by Swati 
            // echo $this->render('replyForm', array('model' => $model, 'qid' => $fq['id']), false);
              echo $this->render('replyForm', array('model' => $model, 'qid' => $fq['id'], 'forumAnswerFiles' => $forumAnswerFiles));
            ?>
                                            </div>
                                        </TD>
                                    </tr>
                                </table>    
                            </div>
        <?php
        }
        else {
            ?>
                            <div class="divAns no-display ans_<?php echo $fq['id']; ?>">
                                <table border="0" class="tblAnswers first last" cellpadding="5">
                                    <TR>
                                        <td class="ansText">No answers..</td>
                                        <td class="ansPostedOn"></td>
                                    </TR>
                                    <TR class="appendReplyForm">
                                        <TD class="anReplyLink">
                                            <div id="ReplyBox<?php echo $fq['id']; ?>" class="ReplyTxtBox no-display" >
                                                <?php
                                                $model = new ForumAnswers;
                                                $forumAnswerFiles = new ForumAnswerFiles;  // Added by Swati 
                                                // echo $this->render('replyForm', array('model' => $model, 'qid' => $fq['id']), false);
                                                echo $this->render('replyForm', array('model' => $model, 'qid' => $fq['id'], 'forumAnswerFiles' => $forumAnswerFiles));
                                                ?>
                                            </div>
                                        </TD><TD>					
                                        </TD></TR>
                                </table>    
                            </div>
                            <?php
                        }
                        ?>
                    </TD>
                    <TD class="centerAll v_align_top border-white rplyIcon" style="vertical-align:top">
                        <?php
                        if ($stat == 'active') {
                            echo '<span style="color:green;"> Open </span>';
                            ?>
                            <a class="btn btn-small btn-inverse rplyIcon no-display rep_<?php echo $fq['id']; ?>"  onclick="ShowReplyForm(id = '<?php echo $fq['id']; ?>');" ><i class="icon-large icon-edit"></i> Reply</a>	
                            <?php
                        } else {
                            echo '<span style="color:red;"> Close </span>';
                        }
                        ?> 			
                    </TD>
                     <TD class="v_align_top border-white yellow-left" width="300">
                     
                        <?php echo Yii::$app->formatter->asDate($fq['asked_on']); // Updated date format by Swati ?>
                       
                        </TD></TR>
            <?php
            $i++;
        }
        ?>
        </table>
        <?php
    } else {
        echo '<div class = "no-result alert alert-danger" >'."No Result found!".'</div>';       
    }   
    echo '<div class = "cancel-askus">'.Html::a('Cancel', ['/forumquestions/admin'], ['class' => 'btn btn-success']); 
    ?>	
</div>	
<div id="controlHelp" class="modal-header" title="Help" style="display:none">
<?php
$helpInfo = \backend\models\HelpCenter::getPageHelp(15);
if(!empty($helpInfo)){
?>

    <div class="modal-body" id="createkpihelpbd">
        <div class='help_body'>
                <p><?php echo $helpInfo['content']; ?></p>
<?php } ?>
        </div>
    </div>
</div>				
 <?php $js  = "$(document).ready(function() {";
        "$('.ReplyTxtBox').hide();";
        "});";
        "$(document).ready(function() {";
        "$('.sugclass').tooltip({'title': 'Suggestions', 'placement': 'top'});";
        "$('.help').tooltip({'title': 'Assist me', 'placement': 'top'});";
        "});";
 $this->registerJs($js);       
if (empty($forumQue)) { 
            $js1 = "$('#AskQuestionForm').show();";
            "$('#btnAskQuestion').hide();";
 } else { 
            $js1 = "$('#AskQuestionForm').hide();";
            "$('#btnAskQuestion').show();";
 }
   $js1 .= "});";
 $this->registerJs($js1);

  ?>
<script>
    function showForm()
    {
        $('#AskQuestionForm').toggle('show');
    }

    function ShowReplyForm(id)
    {
        $('.RplyErrorMsg' + id).hide();
        $('#ReplyBox' + id).toggle('show');
    }

/*
    jQuery(function($) {
       // $(".alert-success").delay(3000).fadeOut("slow");
        //$(".alert-warning").delay(3000).fadeOut("slow");
        //$(".alert-info").delay(3000).fadeOut("slow");
    });*/
    function submitForm()
    {
        $('#forum-quest-form').submit();
    }
    function displayinfo(id)
    {
        $('.ans_' + id).toggle('slow');
        $('.rep_' + id).toggle('slow');
        if ($('.rep_' + id).css('display') == 'inline') {
            $('.rep_' + id).css('display', 'block');
        }
//    else {
//        $('.rep_'+id).css('display','none');
//    }
    }
    
    
    function remove_files(fileId,type)
    {  
        $('#'+fileId).addClass('ques-files-'+fileId);
      
        $.ajax({
            type: 'post',
            url: "<?php echo \Yii::$app->getUrlManager()->createUrl('forumquestions/deletefiles') ?>",
            // url: "<?php //echo $del; ?>",
            global: false, // it will not trigger the ajaxStart event for the call - added by sucheta
            data: {fileId: fileId, type: type},
            success: function(response) {           
                if(response == 1) {
                    $('.ques-files-'+fileId).remove(); 
                    $('#img-'+fileId).remove();  
                    $('#'+fileId).remove(); 
                    // location.reload();
                } else {
                    show_alert('Something Went Wrong, Please Try again','Error !!');
                }
            }
        });     
    }
    
    function confirmDelete(fileId, type)
    {        
        var yesFun = "remove_files(" + fileId+","+type + ");close_alert();";
        var noFun = 'close_alert();';
        var confirmMsg = "Are you sure you want to delete this resource file?";
        show_confirm(confirmMsg, yesFun, noFun, 'Confirm');
    }


</script>