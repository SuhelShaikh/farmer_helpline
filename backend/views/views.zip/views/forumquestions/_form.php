<?php 
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
?>

<div class = "forum-sp-error-msg no-display">	
    <p style="color:#b94a48">Please enter your question.</p>
</div>
 <?php $form = ActiveForm::begin([
    'layout'=>'horizontal',
    'id'=>'forum-questions',
    'action'=>'create',
    'options' => [
        'class' => '',
        'enctype'=>'multipart/form-data',  
        'name'=>'forumquestions',
    ],   
    ]); 
?>

<?php // echo $form->errorSummary($model); ?>
<?= $form->field($model, 'question')->textarea(array('placeholder' => 'Enter Your Question'))->label(false); ?>
<?php if(isset($forumQuestionFiles)) {
   echo $form->field($forumQuestionFiles, 'questionFile[]')->fileInput(['multiple' => true]);  // Added by Swati
} ?>
<?php // echo $form->field($forumQuestionFiles, 'questionFile[]')->fileInput(['multiple' => true]) // Added by Swati ?>
<?php // echo  Html::submitButton('POST YOUR QUESTION',['onClick'=>'validateForum(event);']); ?>
<?php echo Html::submitButton($model->isNewRecord ? 'POST YOUR QUESTION' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-primary' : 'btn btn-primary']) ?>

<?php ActiveForm::end(); ?>

<?php 
/*
  $js = "$(document).ready(function(){";
    "$('.forum-sp-error-msg').hide();";
    "});";
    $this->registerJs($js);*/
?>

