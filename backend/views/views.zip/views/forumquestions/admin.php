<?php 
use frontend\models\ForumQuestions;
use frontend\models\ForumAnswers;
use frontend\models\UserPackage;
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use backend\models\HelpInfo;
use frontend\models\ForumAnswerFiles;
use frontend\models\ForumQuestionFiles;

$baseUrl = Yii::$app->getUrlManager()->getBaseUrl(); ?>

<div id="support_forum" class="discussionForum" >
	<div class="tabs-icons">
   		<h1 class="text pull-left">Ask Us How</h1>
		<div class="clearfix"></div>
	</div>

    <div class="ask-question">
    <?php
		//code to get current week message limit for trial and single user 
		$userPckgId = UserPackage::getUserPackageDetails(Yii::$app->user->getId());
		$pckgLimit = UserPackage::getPackageLimitByType('message'); 
		if ($pckgLimit != -1) {
			if (date('D') != 'Mon') {
				$staticstart = date('Y-m-d', strtotime('last Monday'));
			} else {
				$staticstart = date('Y-m-d');
			}
			if (date('D') != 'Sun') {
				$staticfinish = date('Y-m-d', strtotime('next Sunday'));
			} else {
				$staticfinish = date('Y-m-d');
			}                
			$countWeekMessage = ForumQuestions::getMessagesBetweenDate($staticstart, $staticfinish);
                        //echo '<pre>';print_r($countWeekMessage);exit;
			$availableLimit = $pckgLimit - $countWeekMessage;
			if($availableLimit > 0) {
                            if(count($forumQue)!=0){
			   ?>
    <?= Html::button('ask a question', ['class'=> 'btn btn-inverse q-ask','onclick' => 'showForm()', 'id' => "btnAskQuestion"]) ;?>
<?php 
        }
     } else {
           
?>            
        <div class="pull-left limit-exceed">
            <span class="rpt-limit badge-warning">Your Mesaage limit exceeded for current week.</span>                
        </div>
            
		<?php
            }
        } else { 
            if(count($forumQue)!=0){
            ?>
            
                <?= Html::submitButton('ask a question', ['class'=> 'btn btn-inverse q-ask','onclick' => 'showForm()', 'id' => "btnAskQuestion"]) ;?>

            <?php   }}
        
        ?>   
        <div class="searchbox pull-right">
                    <?php $form = ActiveForm::begin([
                    'layout'=>'horizontal',
                    'id'=>'forum-questions-form',
                    'action'=>'admin',
                    'method'=>'post',
                    'options' => [
                    'class' => 'pull-right',
                    'enctype'=>'multipart/form-data',  
                    'name'=>'forumquestions',
                     ],
                ]); ?>
			<?=  $form->field($model, 'question')->textInput()->input('', ['placeholder' => "Search..."])->label(false); ?>
            <?= Html::submitButton('', ['class'=> 'btn btn-inverse q-search']) ;?>
	    	<?php ActiveForm::end(); ?>
		</div> 
        <div class="clearfix"></div>
  </div>   

    <div class="fr supp">
        <?php
        //	$this->widget('bootstrap.widgets.TbButton',array(
        //	'url'=>array('/Kpi/addKpiData'),
        //	'label' => 'Go Back',
        //	'type'=>'inverse',
        //	'size'=>'mini',
        //	'htmlOptions'=> array('class'=>'fr'),
        //	));
        ?>
    </div>
    <?php
   /*$this->widget('bootstrap.widgets.TbAlert', array(
        'block' => true, // display a larger alert block?
        'fade' => true, // use transitions?
        'closeText' => '×', // close link text - if set to false, no close link is displayed
        'alerts' => array(// configurations per alert type
            'success' => array('block' => true, 'fade' => true, 'closeText' => '×'), // success, info, warning, error or danger
            'warning' => array('block' => true, 'fade' => true, 'closeText' => '×'), // success, info, warning, error or danger
            'info' => array('block' => true, 'fade' => true, 'closeText' => '×'),
        ),
    ));*/
    ?>
    <?php
    if (empty($forumQue)) {
        $classdisp = '';
        $style = 'display:block';//if no qeuestion been asked show ask us how form.
    } else {
        $classdisp = 'no-display';
        $style = '';//if at least one question has been asked show ask us how form on ask a question button click only.
    }
    ?>

    <div id="AskQuestionForm" class="no-display" style="<?php echo $style; ?>">
        <?php
        //echo $pckgLimit .'-'. $countWeekMessage;
        //$model = new ForumQuestions();
        // secho '<pre>'; print_r($forumQuestionFiles); 
        if(isset($forumQuestionFiles)) {
            echo $this->render('_form', array('model' => $model, 'forumQuestionFiles' => $forumQuestionFiles));
        } else {
            echo $this->render('_form', array('model' => $model));
        }      
        //echo CHtml::link('Advanced Search','#',array('class'=>'search-button btn')); 
        ?>       
    </div>


    <?php
    if (!empty($forumQue)) {
        ?>	
        <table border="0" class="ClsQueAnswers" cellpadding="10">
            <TR class="QueHeader">
               
                <TD class="QHeader first" >Question</TD>
                <TD class="headerStatus">Status</TD>
                <TD class="onHeader last">Date</TD>
            </TR>
            <?php
      
            $i = 1;           
            foreach ($forumQue as $fq) {
                ?>
                <TR class="<?php if ($i % 2 == 0) {
            echo "even";
        } else {
            echo "odd";
        } ?>" >
                    
                    <TD class="v_align_top border-white yellow-left" width="300">                    
                        <p class="QuestionText">
                            <span id="<?php echo $fq['id'];?>" onclick="displayinfo(<?php echo $fq['id'] ?>);"> <?php echo $fq['question']; ?></span>  
                            <span onclick="displayinfo(<?php echo $fq['id'] ?>);" class="pull-right"></span>
                        </p>
                        <?php
                            $fileLoc = ForumQuestionFiles::getFileNameFromQuestionId($fq['id']);                            
                            $showLightBox1 = 0;
                            $showLightPDF1 = 0;
                            if(!empty($fileLoc)) {
                                foreach($fileLoc as $loc) {                                   
                                    $filePath = $loc['file_path']; 
                                    $path_parts = pathinfo($filePath);
                                    $fileExt =  $path_parts['extension'];               
                                    if($fileExt == 'pdf') {    
                                        // ForumQuestionFiles::generateQuesFiles($fq['id']); 
                                        $showLightPDF1 = 1;
                                    } else if($fileExt == 'jpg' || $fileExt == 'png') {
                                        $showLightBox1 = 1;  
                                    }
                                }
                                if($showLightPDF1 == 1) {
                                    ForumQuestionFiles::generateQuesFiles($fq['id']);
                                }
                                 if($showLightBox1 == 1) {
                                    $items = ForumQuestionFiles::generateQuesImages($fq['id']);                                   
                                    foreach($items as $key => $val) {
                                       $fileId = $val['options']['id'];
                                       ?>
                                        <i class="glyphicon glyphicon-remove removeimage" id="img-<?php echo $fileId ;?>" type=1 onclick="return confirmDelete(<?php echo $fileId; ?>,1);"></i>      
                                 <?php   }
                                    ?>
                                    <?php 
                                    $rand = mt_rand(10,1000);
                                    echo dosamigos\gallery\Gallery::widget([
                                       'items' => $items,
                                       'options' => [
                                           'id' => 'gallery-widget-' . $fq['id'].$rand,
                                       ],
                                       'templateOptions' => [
                                           'id' => 'blueimp-gallery-' . $fq['id'].$rand
                                       ],
                                       'clientOptions' => [
                                           'container' => '#blueimp-gallery-' . $fq['id'].$rand
                                       ]
                                   ]);                                
                                }
                            } 
                        ?>
                        <p> <?php //$items = ForumQuestionFiles::generateQuesFileArray($fq['id']);                       
                                //echo dosamigos\gallery\Gallery::widget(['items' => $items]); ?> </p> 
                        <?php
                       $QueReplies = ForumQuestions::GetQuestionReplies($fq['id']);
                       
                       $stat = $fq['admin_approve'];				
                        if (!empty($QueReplies)) { ?>
                            <!-- Code for hiding & showing i.e. toggoling Question & Answer section - Swati -->
                            <p class="pull-left answer-restrict">
                                <?php
                                    $ans = substr($QueReplies[0]['answer'], 0, 25);
                                    $ans.='...';
                                ?>
                                <span class='expand-ques' onclick="displayinfo(<?php echo $fq['id'] ?>);"><?php echo $ans; ?></span>
                            </p>
                            <div class="clr"></div>
                            <div class="divAns no-display ans_<?php echo $fq['id']; ?>"> 
                            <!-- End toggoling Question & Answer section  -->
                            <div class="divAns">
                                <table border="0" class="tblAnswers first last" cellpadding="5">                                
                                    <?php
                                    foreach ($QueReplies as $rply) {
                                        $replyRole = \frontend\models\UserRole::findOne($rply['user_id']);
                                        if($replyRole['role_id'] == 1) {
                                                $classOfUser = 'admin-user';
                                                $rply['answer'];
                                                $labelfor = '<span class="reply-lb">Admin: </span>';
                                        } else {
                                                $classOfUser = 'user-user';
                                                $labelfor = '<span class="reply-lb">User: </span>';
                                        }
                                    ?>
                                        <TR class="<?php echo $classOfUser; ?>">
                                <?php 
                                    ?>
                                        <TD class="ansText">
                                            <span class="SpanAns"> </span>
                                            <?php
                                            if ($rply['correct_answer'] == '1') {
                                                ?>
                                                <img src="<?php echo $baseUrl; ?>/frontend/web/blue/images/tick.png" title="Marked as right answer" alt="right answer"/>
                                                <?php
                                            }
                                            echo $labelfor;
                                            echo '<span class="ans">'.$rply['answer'].'</span>'; 
                                            echo '<div class="clearfix"></div>';
                                            /* Added by Swati - for  showing attachemnt & lightbox gallery for images */ 
                                            $showLightBox = 0;
                                            $showLightPDF = 0;
                                            // ForumAnswerFiles::generateAnswerPath($rply['id']);  // Added by Swati                                                   
                                            $fileLoc = ForumAnswerFiles::getFileNameFromAnswersId($rply['id']);                                           
                                            if(!empty($fileLoc)) {  
                                                foreach($fileLoc as $loc) {
                                                    $filePath = $loc['file_path']; 
                                                    $path_parts = pathinfo($filePath);
                                                    $fileExt =  $path_parts['extension'];               
                                                    if($fileExt == 'pdf') {    
                                                       // ForumAnswerFiles::generateAnsFiles($rply['id']);   
                                                        $showLightPDF = 1;
                                                    } else if($fileExt == 'jpg' || $fileExt == 'png') {
                                                        $showLightBox = 1;                                                        
                                                    }                                                       
                                                }
                                                if($showLightPDF == 1) {
                                                    ForumAnswerFiles::generateAnsFiles($rply['id']); 
                                                }
                                                
                                                if($showLightBox == 1) {
                                                    $items = ForumAnswerFiles::generateAnsImages($rply['id']);
                                                    //echo dosamigos\gallery\Gallery::widget(['items' => $items]);
                                                    foreach($items as $key => $val) {
                                                        $fileId = $val['options']['id'];
                                                    ?>
                                                        <i class="glyphicon glyphicon-remove removeimage" id="ansFile-<?php echo $fileId ;?>" type=2 onclick="return confirmDelete(<?php echo $fileId; ?>,2);"></i>      
                                                    <?php   }
                                                    echo dosamigos\gallery\Gallery::widget([
                                                    'items' => $items,
                                                        'options' => [
                                                            'id' => 'gallery-widget-' . $rply['id'],
                                                        ],
                                                        'templateOptions' => [
                                                            'id' => 'blueimp-gallery-' . $rply['id']
                                                        ],
                                                        'clientOptions' => [
                                                            'container' => '#blueimp-gallery-' . $rply['id']
                                                        ]
                                                    ]);
                                                }
                                            }  
                                            /* End Swati */
                                        ?> 
                                        </TD><TD class="ansPostedOn number"><?php  echo Yii::$app->formatter->asDate($rply['ans_on']); ?></TD>
                                            <!--<TD class="ansPostedOn number"><?php  //echo Yii::$app->formatter->asDatetime("d MMM y", strtotime($fq['asked_on'])); ?></TD>-->
                                        </TR>                                       
                                        <?php                                     
                                        }
                                    ?>
                                  
                                    <TR class="appendReplyForm">
                                        <TD class="anReplyLink">
                                            <div id="ReplyBox<?php echo $fq['id']; ?>" class="ReplyTxtBox no-display" >
                                                <?php 
                                                $model = new ForumAnswers;
                                              //   $forumAnswerFiles = new ForumAnswerFiles;  // Added by Swati 
                                                echo $this->render('replyForm', array('model' => $model, 'qid' => $fq['id'], 'forumAnswerFiles' => $forumAnswerFiles));
                                                ?>
                                            </div>
                                        <!--</TD><TD>-->

                                        </TD></TR>
                                       
                                </table>
                            </div>
                        </div>
                            <?php
                        } else {
                            ?>
                            <div class="divAns no-display ans_<?php echo $fq['id']; ?>">
                                <table border="0" class="tblAnswers first last" cellpadding="5">
                                    <TR>
                                        <td class="ansText">No answers..</td>
                                        <!--<td class="ansPostedOn"></td>-->
                                    </TR>
                                    <TR class="appendReplyForm">
                                        <TD class="anReplyLink">
                                            <div id="ReplyBox<?php echo $fq['id']; ?>" class="ReplyTxtBox no-display" >
                                                <?php
                                                $model = new ForumAnswers;
                                              //   $forumAnswerFiles = new ForumAnswerFiles;  // Added by Swati 
                                                echo $this->render('replyForm', array('model' => $model, 'qid' => $fq['id'], 'forumAnswerFiles' => $forumAnswerFiles));                                             
                                                // echo $this->render('replyForm', array('model' => $model, 'qid' => $fq['id']), false);
                                                ?>
                                            </div>
                                        </TD>
                                       <!-- <TD></TD>-->
                                     </TR>
                                </table>    
                            </div>
                            <?php
                        }
                        ?>
                        </TD>
                      <TD class="v_align_top border-white yellow-left" width="300">
                       
                      <?php
                       if ($stat == 'active') {
                            echo '<span style="color:green;"> Open </span>';
                            ?>
                            <a class="btn btn-small btn-inverse rplyIcon no-display rep_<?php echo $fq['id']; ?>"  onclick="ShowReplyForm(id = '<?php echo $fq['id']; ?>');" ><i class="icon-large icon-edit"></i> Reply</a>	
                            <?php
                        } else {
                            echo '<span style="color:red;"> Close </span>';
                        }
                        ?> 
                         
                        
                        </TD>
                        <TD class="v_align_top border-white yellow-left" width="300">
                     
                        <?php echo Yii::$app->formatter->asDate($fq['asked_on']); // Updated date format by Swati ?>
                       
                        </TD>
                       
                    </TR>
        <?php
        $i++;
    }
    ?>
        </table>
        <?php
    } else { ?>
        <?php //echo '<div class="text">No Result found!</div>';
        }
    ?>

</div>


<!--
Added On : 11/7/2016.
Added By : Sushrut Deshpande.
Added to get help information on click of help button.
-->
    <div class="help-info" style="display:none;">
    <?php 
    //$helpInfo = HelpInfo::getHelpInfo('Forum Question', 'Forum Question'); 
    $helpInfo = \backend\models\HelpCenter::getPageHelp(15);
        $hasHelp = 0; // Added by Swati
        if(!empty($helpInfo)) {        
            $hasHelp = 1; 
            echo $helpInfo['content']; 
    ?>
            <span class='btn help-button' onclick="window.location ='<?php echo $baseUrl; ?>'+'/helpcenter/help'">Need More Help?</span> <!--  Added by Swati -->
    <?php } ?>
    </div>
    <div id="controlHelp" class="modal-header" title="Help" style="display:none">
        <div class="modal-body" id="createkpihelpbd">
            <div class='help_body help-content'>
            </div>
        </div>
    </div>

<?php
  // Added by Swati - to show help option if help exists
    $helpJs = '
        $(document).ready(function(){   
            var helpExists = "'.$hasHelp.'";       
            if(helpExists == 1) {
                $("#idControlHelp").show();
            }
        });      
    ';
    $this->registerJs($helpJs);
    

$this->registerJsFile(Yii::getAlias('@web/frontend/web/js/helpinfo.js'), ['depends' => [\yii\web\JqueryAsset::className()]]); 
$this->registerJsFile(Yii::getAlias('@web/frontend/web/js/askushow/askushow.js'), ['depends' => [\yii\web\JqueryAsset::className()]]);
 ?>

<script>
    function displayinfo(id)
    {
		$('#' + id).toggleClass("questtext");
        $('.ans_' + id).toggle('slow');
        $('.rep_' + id).toggle('slow');
        if ($('.rep_' + id).css('display') == 'inline') {
            $('.rep_' + id).css('display', 'block');
        }
//    else {
//        $('.rep_'+id).css('display','none');
//    }


    }  
    
    function remove_files(fileId,type)
    {      
        $('#'+fileId).addClass('ques-files-'+fileId);
      
        $.ajax({
            type: 'post',
            url: "<?php echo \Yii::$app->getUrlManager()->createUrl('forumquestions/deletefiles') ?>",
            // url: "<?php //echo $del; ?>",
            global: false, // it will not trigger the ajaxStart event for the call - added by sucheta
            data: {fileId: fileId, type: type},
            success: function(response) {           
                if(response == 1) {
                    $('.ques-files-'+fileId).remove(); 
                    $('#img-'+fileId).remove(); 
                    $('#'+fileId).remove(); 
                    $('#ansFile-'+fileId).remove();
                    // location.reload();
                } else {
                    show_alert('Something Went Wrong, Please Try again','Error !!');
                }
            }
        });    
    }
</script>