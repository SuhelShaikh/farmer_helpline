
<?php $form = ActiveForm::begin([
                        'layout'=>'horizontal',
                        'id'=>'forum-questions-form',
                        'action'=>'admin',
                        'method'=>'get',
                        'options' => [
                        'class' => 'pull-right',
                        'enctype'=>'multipart/form-data',  
                        'name'=>'forumquestions',
                         ],
                    ]); ?>
<?php/* $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
));*/ ?> 
 <?=  $form->field($model, 'question') ?>

		<?php //echo $form->textFieldRow($model,'question',array('class'=>'span5','maxlength'=>500, 'placeholder'=>'Search Question..?')); ?>

		<?php /*$this->widget('bootstrap.widgets.TbButton', array(
			'buttonType' => 'submit',
			'type'=>'primary',
			'label'=>'Search',
			'htmlOptions'=>array('class'=>'search_btn'),
		)); ?>
<?php $this->endWidget();*/ ?>
        <?= Html::submitButton('Search',['class'=>'btn btn-primary search_btn']) ?>
	    <?php ActiveForm::end(); ?>

<script type="text/javascript">
$(document).ready(function(){.0
//   $("#forum-questions-grid .items td:nth-child(1)").css("width","15%");
//   $("#forum-questions-grid .items td:nth-child(2)").css("font-size","14px");
//    $("#forum-questions-grid .items td:nth-child(3)").css({"width":"13%","text-align":"center","color":"#999"});
});
</script>