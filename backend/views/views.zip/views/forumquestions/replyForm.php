<?php use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use frontend\models\ForumQuestions;
use frontend\models\ForumQuestionFiles;
?> 
<?php $form = ActiveForm::begin([
                        'layout'=>'horizontal',
                        'id'=>'forum-answers-form'.$qid,
                        'action'=>'reply',
                        //'enableAjaxValidation'=>true,
                        'options' => [
                        'class' => '',
                        'enctype'=>'multipart/form-data',  
                        'name'=>'forumAnsReply',
                            
                         ],
     
                    ]); ?>
<?php
$userId = Yii::$app->user->getId();
?>
<div class ="RplyErrorMsg<?php echo $qid; ?>" style="color:#b94a48; display:none;"> Reply cannot be Empty!! </div>
	<?php // echo $form->hiddenField($model,'que_id',array('class'=>'span5','value'=>$qid)); ?>
        <?php echo yii\helpers\Html::hiddenInput('que_id', $qid); ?> 
        <?= $form->field($model, 'answer')->textarea(array('placeholder' => 'Post Your Reply...'))->label(false); ?>
        <?php if(isset($forumAnswerFiles) ){
           echo $form->field($forumAnswerFiles, 'answerFile[]')->fileInput(['multiple' => true, 'id'=>'Ans-'.$qid])->label(false);  // Added by Swati
        } ?>
	<?php // echo $form->textField($model,'ams_on',array('class'=>'span5'));// ?>
	<?php $Question = ForumQuestions::find()->where('id = :id', ['id'=>$qid])->all(); 
            if($Question[0]['admin_approve'] =="inactive") {
                $selested ="checked";
            } else {
                $selested = "selected=false";
            }      
	?>
	<p class="CheckData text">
            <?php if($userId == $Question[0]['user_id']) {
            ?>
            <input type="checkbox" class="CheckStatus" name="ForumAnswers[admin_approve]" <?php echo $selested; ?> >Check to mark as close.</input>
            <?php } ?>
        </p>
	<?php //echo $form->checkboxRow($model, 'admin_approve',array('class'=>'')); ?>

<div class="form-actions">

    
      
        <?= Html::submitButton('POST') ?>
    <?php ActiveForm::end(); ?>

        <?php
// 		$this->widget('bootstrap.widgets.TbButton',array(
// 			 'url'=>array('/forumQuestions/admin'),
// 				'label' => 'Go Back',
// 				'type'=>'primary',
// 				//0'size' => 'small',
// 				'htmlOptions'=> array('class'=>'fl westspace3 '),
// 			));
		?>
       
</div>
<div class="clr" ></div> 
	    



<script>

/*function validateRply(event,qid)
{
	//alert(qid);
	var value = $('.frm-Rply'+qid).val();
        alert(value);
	if(value && value !="Post your reply..."){
		$('.RplyErrorMsg'+qid).hide();
		event.returnValue = true;
		//document.forumAnsReply.submit();
		//$('#forum-answers-form'+qid).submit();
                event.preventDefault();
                return false;
		}else{
		$('.RplyErrorMsg'+qid).show();
		event.returnValue = false;
                 event.preventDefault();
		return false;
	}	
}
*/

</script>